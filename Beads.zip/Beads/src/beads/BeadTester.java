/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beads;

/**
 *
 * @author acer
 */
public class BeadTester {
    public static void main(String[] args) {
        Beads b1=new Beads("white",'c');
//        b1.setColor("white");
//        b1.setLetter('c');
        
        System.out.println(b1.getColor()+" "+b1.getLetter());
    }
}
